# TASK_REPORT_ANSWERS (copy into your PDF report, in your own words where you can)

## 1. How Firebase integration works
`google-services.json` (downloaded from my Firebase project and placed in `app/`) tells the app which Firebase project and
database to use. The Google-services Gradle plugin reads it at build time. The Firebase BoM (34.18.0) picks matching versions
for `firebase-database`. The INTERNET permission in the manifest lets the app reach Firebase. The Realtime Database is in
test mode, so reads and writes are allowed. Every post is stored under the node `LostFound/<push key>`.
`FirebaseHelper` creates the `LostFound` DatabaseReference, and `LostFoundApp` turns on offline disk persistence.

## 2. How the app posts Lost and Found items
In `PostItemActivity` the student enters item name, location and contact and chooses Lost or Found. If a field is empty,
`setError()` shows a message and nothing is saved. Otherwise the app calls `ref.push().getKey()` to create a unique,
time-ordered key, stores that key as the item's `id`, sets `status = "Open"`, and calls `ref.child(key).setValue(item)`.
An `OnCompleteListener` shows a Toast and calls `finish()` on success, or shows the error message on failure.
Firebase uses the getters of `LostItem` to write and the no-argument constructor plus setters to read.

## 3. How the RecyclerView displays items
`MainActivity` holds an `ArrayList<LostItem>` and a `LostItemAdapter`. The adapter inflates `item_lost.xml` (a CardView with
`cardCornerRadius` and `cardElevation`) in `onCreateViewHolder()`, fills the views in `onBindViewHolder()`, and returns the list
size in `getItemCount()`. A static inner `ViewHolder` keeps the view references. A `ValueEventListener` added with
`addValueEventListener()` clears the list, adds each child as `getValue(LostItem.class)`, reverses the list
(push keys are time-ordered, so the newest post is last, and reversing puts it first), then calls `notifyDataSetChanged()`.
When the snapshot has no children the "No items posted yet" message is shown instead of the list.

## 4. How tapping a card changes its status to Returned
The adapter gives the clicked item to the `OnItemClickListener` (Lab Task 2) in `MainActivity`, which runs
`ref.child(item.getId()).child("status").setValue("Returned")`. Only the `status` child is written; the other fields are untouched.
Because the listener is live, every phone gets the change, and the adapter shows Returned cards with a grey background and a
"Returned" label.

## 5. Offline write test and expected observation
Steps: post 5 items (Lost and Found) online and capture the `LostFound` tree in the Console. Turn the emulator's internet off
(swipe down, switch Wi-Fi/data off, or turn on Airplane mode). Post one more item.
Expected observation:
- On the device: the form stays open and the success Toast does not appear yet, because the completion listener only fires when
  the server confirms the write. Press Back: the new item already appears on the board, because Firebase writes it to its local
  cache and fires the live listener immediately.
- In the Firebase Console: the new item is NOT there.
Turn the network back on: Firebase automatically sends the queued write, and the item appears in the Console under `LostFound`.
(If you left the form open, its completion listener now fires, the Toast shows and the screen closes.)
Reason: the Realtime Database SDK keeps a local copy and a queue of pending writes (offline persistence is enabled in
`LostFoundApp`) and syncs them automatically when the connection returns.

## 6. Live Firebase update test
With the app open on the board, go to the Firebase Console, open one post and edit its `location` value, then confirm.
The card in the app changes by itself, with no tap and no refresh. Then tap a card in the app to mark it Returned and check
that its `status` in the Console now shows `Returned`.

## 7. Difference between ValueEventListener and a single-value listener
`addValueEventListener()` stays attached and calls `onDataChange()` now and again every time anything under `LostFound` changes
(new post, Console edit, Returned tap by anyone), so the board updates itself. `addListenerForSingleValueEvent()` reads the
data once and then detaches, so the board would become out of date and would need a manual refresh.
(The live listener is removed in `onDestroy()` with `removeEventListener()` to avoid leaks.)

## 8. Screenshots to take
1. Post Item form (ideally one showing a setError message, plus the normal form).
2. The board with at least 5 posts (Lost and Found mixed).
3. A Returned (grey) card.
4. Firebase Console > Realtime Database > Data, showing the `LostFound` tree (with the 5+ posts) and the database URL.
5. Offline test: the device after posting offline, and the Console at that time (item missing), then the Console after network is back.
6. Live test: the Console while editing a location, and the card in the app after it changed.
7. Console showing `status: "Returned"` after tapping a card.
8. GitHub repository page (public) and its link on the first page of the report.
