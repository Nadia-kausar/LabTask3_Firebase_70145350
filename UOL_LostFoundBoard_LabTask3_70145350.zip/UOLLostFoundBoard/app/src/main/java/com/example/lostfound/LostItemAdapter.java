package com.example.lostfound;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class LostItemAdapter extends RecyclerView.Adapter<LostItemAdapter.ViewHolder> {

    /** Item click interface (Lab Task 2). */
    public interface OnItemClickListener {
        void onItemClick(LostItem item);
    }

    private final ArrayList<LostItem> items;
    private final OnItemClickListener listener;

    public LostItemAdapter(ArrayList<LostItem> items, OnItemClickListener listener) {
        this.items = items;
        this.listener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final CardView card;
        final TextView tvItemName, tvType, tvLocation, tvContact, tvStatus;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            card       = (CardView) itemView;
            tvItemName = itemView.findViewById(R.id.tvItemName);
            tvType     = itemView.findViewById(R.id.tvType);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvContact  = itemView.findViewById(R.id.tvContact);
            tvStatus   = itemView.findViewById(R.id.tvStatus);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_lost, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LostItem item = items.get(position);
        int ctxColorBlack = ContextCompat.getColor(holder.itemView.getContext(), android.R.color.black);
        int white = ContextCompat.getColor(holder.itemView.getContext(), android.R.color.white);
        int grey = ContextCompat.getColor(holder.itemView.getContext(), R.color.card_returned);
        int darkGrey = ContextCompat.getColor(holder.itemView.getContext(), android.R.color.darker_gray);

        holder.tvItemName.setText(item.getItemName());
        holder.tvType.setText(item.getType() == null ? "" : item.getType().toUpperCase());
        holder.tvLocation.setText("\uD83D\uDCCD " + item.getLocation());
        holder.tvContact.setText("\uD83D\uDCDE " + item.getContact());

        boolean lost = "Lost".equalsIgnoreCase(item.getType());
        holder.tvType.setTextColor(ContextCompat.getColor(holder.itemView.getContext(),
                lost ? R.color.lost_red : R.color.found_green));

        if ("Returned".equals(item.getStatus())) {
            holder.tvStatus.setText("\u2713 Returned");
            holder.tvStatus.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.found_green));
            holder.card.setCardBackgroundColor(grey);      // grey card = Returned
            holder.tvItemName.setTextColor(darkGrey);
        } else {
            holder.tvStatus.setText("\u25CF Open");
            holder.tvStatus.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.open_orange));
            holder.card.setCardBackgroundColor(white);
            holder.tvItemName.setTextColor(ctxColorBlack);
        }

        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
