package com.example.lostfound;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;

public class PostItemActivity extends AppCompatActivity {

    private EditText etItemName, etLocation, etContact;
    private RadioGroup rgType;
    private Button btnPost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_item);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        etItemName = findViewById(R.id.etItemName);
        etLocation = findViewById(R.id.etLocation);
        etContact  = findViewById(R.id.etContact);
        rgType     = findViewById(R.id.rgType);
        btnPost    = findViewById(R.id.btnPost);

        btnPost.setOnClickListener(v -> postItem());
    }

    private void postItem() {
        String name     = etItemName.getText().toString().trim();
        String location = etLocation.getText().toString().trim();
        String contact  = etContact.getText().toString().trim();

        // Refuse empty fields with setError()
        if (name.isEmpty()) {
            etItemName.setError("Item name is required");
            etItemName.requestFocus();
            return;
        }
        if (location.isEmpty()) {
            etLocation.setError("Location is required");
            etLocation.requestFocus();
            return;
        }
        if (contact.isEmpty()) {
            etContact.setError("Contact is required");
            etContact.requestFocus();
            return;
        }

        String type = (rgType.getCheckedRadioButtonId() == R.id.rbFound) ? "Found" : "Lost";

        // Reference to LostFound, then a new unique push key
        DatabaseReference ref = FirebaseHelper.getLostFoundRef(this);
        String key = ref.push().getKey();
        if (key == null) {
            Toast.makeText(this, "Could not create a key for the post", Toast.LENGTH_LONG).show();
            return;
        }

        // The push key is stored as the item's id; new posts start as "Open"
        LostItem item = new LostItem(key, name, type, location, contact, "Open");

        ref.child(key).setValue(item).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(PostItemActivity.this, "Item posted", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                String msg = (task.getException() != null && task.getException().getMessage() != null)
                        ? task.getException().getMessage() : "Post failed";
                Toast.makeText(PostItemActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
