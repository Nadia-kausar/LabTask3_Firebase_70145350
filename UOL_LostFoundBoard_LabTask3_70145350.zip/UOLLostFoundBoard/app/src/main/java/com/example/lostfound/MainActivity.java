package com.example.lostfound;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private View emptyView;
    private ExtendedFloatingActionButton btnPostItem;

    private final ArrayList<LostItem> list = new ArrayList<>();
    private LostItemAdapter adapter;

    private DatabaseReference ref;
    private ValueEventListener listener;   // kept in a field so it can be removed in onDestroy()

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        emptyView    = findViewById(R.id.emptyView);
        btnPostItem  = findViewById(R.id.btnPostItem);

        ref = FirebaseHelper.getLostFoundRef(this);

        // Tapping a card writes ONLY the status child of that item
        adapter = new LostItemAdapter(list, item -> {
            if (item.getId() == null) return;
            ref.child(item.getId()).child("status").setValue("Returned")
                    .addOnFailureListener(e -> Toast.makeText(MainActivity.this,
                            e.getMessage() == null ? "Update failed" : e.getMessage(),
                            Toast.LENGTH_LONG).show());
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        btnPostItem.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, PostItemActivity.class)));

        // Live read: runs now and again whenever anything under LostFound changes
        listener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    LostItem item = child.getValue(LostItem.class);
                    if (item != null) {
                        list.add(item);
                    }
                }
                Collections.reverse(list);   // push keys are time-ordered: reverse = newest first
                adapter.notifyDataSetChanged();

                boolean empty = !snapshot.hasChildren();
                emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
                recyclerView.setVisibility(empty ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        };
        ref.addValueEventListener(listener);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (ref != null && listener != null) {
            ref.removeEventListener(listener);
        }
    }
}
