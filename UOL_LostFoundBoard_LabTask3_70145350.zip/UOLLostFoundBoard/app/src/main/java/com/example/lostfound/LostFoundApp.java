package com.example.lostfound;

import android.app.Application;

/** Runs once when the app starts: turns on the offline disk cache for Firebase. */
public class LostFoundApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            // Must be called before any other Firebase Database call.
            FirebaseHelper.getDatabase(this).setPersistenceEnabled(true);
        } catch (Exception ignored) {
            // Already enabled or database already in use: safe to ignore.
        }
    }
}
