package com.example.lostfound;

import android.content.Context;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/** One place that creates the database objects, so every screen uses the same database. */
public final class FirebaseHelper {

    private FirebaseHelper() { }

    public static FirebaseDatabase getDatabase(Context context) {
        // res/values/firebase_config.xml -> firebase_database_url (empty = use google-services.json)
        String url = context.getString(R.string.firebase_database_url).trim();
        if (url.isEmpty()) {
            return FirebaseDatabase.getInstance();
        }
        return FirebaseDatabase.getInstance(url);
    }

    /** Reference to the LostFound node that holds every post. */
    public static DatabaseReference getLostFoundRef(Context context) {
        return getDatabase(context).getReference("LostFound");
    }
}
