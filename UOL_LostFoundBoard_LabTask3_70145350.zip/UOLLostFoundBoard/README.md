# UOL Lost & Found Board (Lab Task 03)

Android app (Java) that posts Lost / Found items to a Firebase Realtime Database
and shows them live in a RecyclerView of CardViews. Tapping a card marks it Returned.

## Run it
1. Create a Firebase project and register an Android app with package name `com.example.lostfound`.
2. Download `google-services.json` and place it in the `app/` folder
   (it is deliberately not in this public repository).
3. Create a Realtime Database in test mode. If it is not in the US, put its URL in
   `app/src/main/res/values/firebase_config.xml`.
4. Open the project in Android Studio, sync Gradle, and run.
